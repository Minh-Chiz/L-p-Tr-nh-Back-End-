﻿using System.ComponentModel.DataAnnotations;

namespace Bai1.Models
{
    public class TodoItem
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Tiêu đề không được để trống.")]
        [StringLength(100, ErrorMessage = "Tiêu đề không được vượt quá 100 ký tự.")]
        public string Title { get; set; }
        public bool IsCompleted { get; set; }
    }
}