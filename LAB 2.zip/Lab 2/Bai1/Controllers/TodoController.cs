﻿using Microsoft.AspNetCore.Mvc;
using Bai1.Models;
namespace Bai1.Controllers
{
    public class TodoController : Controller
    {
        private static List<TodoItem> _todoItems = new List<TodoItem>
        {
            new TodoItem { Id = 1, Title = "Ôn tập HTML", IsCompleted = false },
            new TodoItem { Id = 2, Title = "Ôn tập CSS", IsCompleted = false },
            new TodoItem { Id = 3, Title = "Ôn tập Bootstrap", IsCompleted = false }
        };

        public IActionResult Index()
        {
            return View(_todoItems);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(TodoItem todoItem)
        {
            if (ModelState.IsValid)
            {
                todoItem.Id = _todoItems.Any() ? _todoItems.Max(item => item.Id) + 1 : 1;
                todoItem.IsCompleted = false;
                _todoItems.Add(todoItem);
                return RedirectToAction(nameof(Index));
            }
            return View(todoItem);
        }

        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var todoItem = _todoItems.FirstOrDefault(item => item.Id == id);
            if (todoItem == null)
            {
                return NotFound();
            }
            return View(todoItem);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id,Title,IsCompleted")] TodoItem todoItem)
        {
            if (id != todoItem.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var existingItem = _todoItems.FirstOrDefault(item => item.Id == id);
                if (existingItem != null)
                {
                    existingItem.Title = todoItem.Title;
                    existingItem.IsCompleted = todoItem.IsCompleted;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(todoItem);
        }
    }
}